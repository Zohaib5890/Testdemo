<?php

// Breaking News.
require get_template_directory() . '/sections/breaking-news.php';

// Banner Section.
require get_template_directory() . '/sections/banner.php';

// Posts Posts Section.
require get_template_directory() . '/sections/posts-list.php';

// Main Widgets Section.
require get_template_directory() . '/sections/main-widgets-section.php';

// Above Footer Widgets Section.
require get_template_directory() . '/sections/above-footer-widgets.php';
