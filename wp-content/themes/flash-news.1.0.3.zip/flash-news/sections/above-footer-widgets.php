<?php if ( is_active_sidebar( 'above-footer-widgets-section' ) ) : ?>
	<div class="above-footer-widgets-section">
		<div class="ascendoor-wrapper">
			<?php dynamic_sidebar( 'above-footer-widgets-section' ); ?>
		</div>
	</div>
<?php endif; ?>
